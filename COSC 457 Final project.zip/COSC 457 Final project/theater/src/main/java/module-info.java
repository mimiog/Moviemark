module com.example.theater {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.theater to javafx.fxml;
    exports com.example.theater;
}