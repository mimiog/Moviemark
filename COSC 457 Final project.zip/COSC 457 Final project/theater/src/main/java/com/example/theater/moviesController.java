package com.example.theater;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.*;
import java.util.Date;
import java.util.ResourceBundle;

public class moviesController implements Initializable {
    @FXML
    private TableView<movieList> moviesTable;
    @FXML
    private TableColumn<movieList, String> columnDate;

    @FXML
    private TableColumn<movieList, String> columnDuration;

    @FXML
    private TableColumn<movieList, Integer> columnMovieCode;

    @FXML
    private TableColumn<movieList, Double> columnRating;

    @FXML
    private TableColumn<movieList, Time> columnTime;

    @FXML
    private TableColumn<movieList, String> columnTitle;


    Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviemark", "root", "password");
    PreparedStatement psMovieList = connection.prepareStatement("SELECT * FROM movie");
    ResultSet resultSet = psMovieList.executeQuery();
    private ObservableList<movieList> list = FXCollections.observableArrayList();;

    FXMLLoader fxmlLoader = new FXMLLoader(moviesController.class.getResource("movies.fxml"));


    @Override
        public void initialize(URL url, ResourceBundle resourceBundle) {

            columnDate.setCellValueFactory(new PropertyValueFactory<movieList, String>("columnDate"));
            columnDuration.setCellValueFactory(new PropertyValueFactory<movieList, String>("columnDuration"));
            columnMovieCode.setCellValueFactory(new PropertyValueFactory<movieList, Integer>("columnMovieCode"));
            columnRating.setCellValueFactory(new PropertyValueFactory<movieList, Double>("columnRating"));
            columnTime.setCellValueFactory(new PropertyValueFactory<movieList, Time>("columnTime"));
            columnTitle.setCellValueFactory(new PropertyValueFactory<movieList, String>("columnTitle"));

            moviesTable.setItems(list);


    }
    public moviesController() throws SQLException {
    }
}
