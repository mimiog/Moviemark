package com.example.theater;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import java.net.URL;
import java.util.ResourceBundle;

public class LoggedInController implements Initializable {
    @FXML
    private Button logoutButton;
    @FXML
    private Button moviesButton;
    @FXML
    private Label welcomeLabel;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        logoutButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                DBUtils.changeScene(event, "mmark.fxml", "Log in", null);
            }
        });

        moviesButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                DBUtils.newScene(event, "movies.fxml", "Movies");
            }
        });


    }

    public void setUserInformation(String username) {
        welcomeLabel.setText("Welcome to Moviemark Towson, " + username);
    }


}

