package com.example.theater;

import java.sql.Time;

public class movieList {

    private String columnDate;
    private String columnDuration;
    private Integer movieCode;
    private Double columnRating;
    private Time columnTime;
    private String columnTitle;


    public movieList(String columnDate, String columnDuration, int movieCode, Double columnRating, Time columnTime, String columnTitle) {
        this.columnDate = columnDate;
        this.columnDuration = columnDuration;
        this.movieCode = movieCode;
        this.columnRating = columnRating;
        this.columnTime = columnTime;
        this.columnTitle = columnTitle;
    }


    public String getColumnDate() {
        return columnDate;
    }

    public String getColumnDuration() {
        return columnDuration;
    }

    public int getMovieCode() {
        return movieCode;
    }

    public Double getColumnRating() {
        return columnRating;
    }

    public Time getColumnTime() {
        return columnTime;
    }

    public String getColumnTitle() {
        return columnTitle;
    }
}
