package com.example.theater;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class SignUpController implements Initializable {

    @FXML
    private Button registerButton;

    @FXML
    private Button loginButton;

    @FXML
    private TextField fnameTextField;

    @FXML
    private TextField lnameTextField;

    @FXML
    private TextField usernameTextField;

    @FXML
    private TextField emailTextField;

    @FXML
    private PasswordField passwordTextfield;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        registerButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (!usernameTextField.getText().trim().isEmpty() && !passwordTextfield.getText().trim().isEmpty() && !fnameTextField.getText().trim().isEmpty() && !lnameTextField.getText().trim().isEmpty() && !emailTextField.getText().trim().isEmpty()) {
                    DBUtils.registerUser(event, usernameTextField.getText(), passwordTextfield.getText(), fnameTextField.getText(), lnameTextField.getText(), emailTextField.getText());

                } else {
                    System.out.println("Please Fill in all Information");
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setContentText("Please complete all fields to register");
                    alert.show();
                }
            }
        });

        loginButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                DBUtils.changeScene(event, "mmark.fxml", "Log In", null);
            }
        });
    }
}
